
import { useState } from "react";
import ItemList from "./ItemList";
const RestaurantCatogaory = ({ data, showItem, setShowIndex}) => {


    const handleClick = () => {
       setShowIndex();
    }

    return (
        <div>
            {/* Header */}
            <div className="w-6/12 mx-auto my-4 bg-gray-100 shadow-lg p-4">
                <div className=" flex justify-between cursor-pointer" onClick={handleClick} >
                    <span className="font-bold text-lg">{data.title} ({data.itemCards.length}) </span>
                    <span>⬇️</span>
                </div>

                <div>
                    {/* Accordion Body */}
                    {showItem && <ItemList items={data.itemCards} />}
                </div>
            </div>


        </div>
    );
};

export default RestaurantCatogaory;