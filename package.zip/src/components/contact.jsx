import React from "react";
const Contact = () => {
    return (
        <div>
            <h1 className="font-bold text-3xl p-4 m-4">Contact Us page</h1>
            <form>
                <input type="text" className="" placeholder="name" />
                <input type="text" className="" placeholder="message" />
                <button>Submit</button>
            </form>
        </div>
    );
};

export default Contact;